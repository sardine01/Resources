# mb.scrollable 1.5.7

__An open source jQuery component to easily build a scrollable group of elements.__

![mb.extruder](http://pupunzi.com/gitHub/mb.scrollable.jpg)

## [go to the demo](http://pupunzi.com/#mb.components/mb.scrollable/scrollable.html)
## [go to the doc](http://wiki.github.com/pupunzi/jquery.mb.scrollable/)
## [go to the blog](http://pupunzi.open-lab.com/mb-jquery-components/jquery-mb-scrollable/)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web
