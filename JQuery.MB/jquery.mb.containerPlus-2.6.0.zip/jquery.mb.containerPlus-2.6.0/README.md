# mb.containerPlus

__An open source jQuery component to easily build a windowed interface.__

![mb.containerPlus](http://dl.dropbox.com/u/1976976/gitHub//mb.containerPlus.png)

## [go to the demo](http://pupunzi.com/#mb.components/mb.containerPlus/containerPlus.html)


[jquery.mb.components](http://pupunzi.com/), another way of thinking the web


